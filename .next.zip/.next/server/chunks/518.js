"use strict";
exports.id = 518;
exports.ids = [518];
exports.modules = {

/***/ 5518:
/***/ ((module) => {

module.exports = JSON.parse('[{"id":1,"title":"Scientists speculate that ours might not be held","img":"blog-1.png","category":"Gaming","author":"miranda h.","date":"25 April 2023"},{"id":2,"title":"The Multiverse is the collection of alternate universes","img":"blog-2.png","category":"Tech","author":"miranda h.","date":"25 April 2023"},{"id":3,"title":"That share a universal hierarchy a large variety of these","img":"blog-3.png","category":"Movie","author":"miranda h.","date":"25 April 2023"},{"id":4,"title":"Universes were originated from another due to a major","img":"blog-4.png","category":"Sports","author":"miranda h.","date":"25 April 2023"},{"id":5,"title":"A hypothetical collection of potentially diverse","img":"blog-5.png","category":"Gaming","author":"miranda h.","date":"25 April 2023"},{"id":6,"title":"Stanford physicists Andrei Linde In a new study","img":"blog-6.png","category":"Tech","author":"miranda h.","date":"25 April 2023"},{"id":7,"title":"Accessible to telescopes, is about 90 billion years","img":"blog-7.png","category":"Movie","author":"miranda h.","date":"25 April 2023"},{"id":8,"title":"Observable universes each of which would comprise","img":"blog-8.png","category":"Sports","author":"miranda h.","date":"25 April 2023"}]');

/***/ })

};
;