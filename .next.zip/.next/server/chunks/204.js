"use strict";
exports.id = 204;
exports.ids = [204];
exports.modules = {

/***/ 5367:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ BlogPost)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./util/blog.json
var blog = __webpack_require__(5518);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/blog/BlogCard1.js


function BlogCard1({ item  }) {
    return /*#__PURE__*/ jsx_runtime.jsx(jsx_runtime.Fragment, {
        children: /*#__PURE__*/ jsx_runtime.jsx("div", {
            className: "col-xl-12",
            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("article", {
                className: "blog_style one has_images",
                id: "post-1576",
                children: [
                    /*#__PURE__*/ jsx_runtime.jsx("div", {
                        className: "image_box ",
                        children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                            href: `/blog/${item.id}`,
                            children: /*#__PURE__*/ jsx_runtime.jsx("img", {
                                src: `/assets/images/blog/${item.img}`,
                                alt: "img",
                                className: "img-fluid"
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "content_box",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "d-flex top align-items-center",
                                children: [
                                    /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                        href: `/blog/${item.id}`,
                                        className: "cat_gry",
                                        children: "Business Insurance"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("span", {
                                        className: "date_tm",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                className: "fi-rr-calendar"
                                            }),
                                            /*#__PURE__*/ jsx_runtime.jsx("time", {
                                                className: "date published",
                                                dateTime: "2023-01-03T10:03:20+00:00",
                                                children: "Jan 3, 2023"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "d-flex authour align-items-center",
                                children: [
                                    /*#__PURE__*/ jsx_runtime.jsx("img", {
                                        alt: "blog",
                                        src: "assets/images/gavatar.png",
                                        className: "img-fluid"
                                    }),
                                    " Bradley R Grady"
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("h2", {
                                className: "tit_ho title_28",
                                children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                    href: `/blog/${item.id}`,
                                    rel: "bookmark",
                                    children: item.title
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "bottom d-flex  align-items-center",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)((link_default()), {
                                        href: `/blog/${item.id}`,
                                        className: "rd_more",
                                        children: [
                                            "Read More ",
                                            /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                className: "fi-rr-arrow-small-right"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("small", {
                                        className: "comments",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                className: "far fa-comment-dots"
                                            }),
                                            /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                href: `/blog/${item.id}`,
                                                className: "Comments are Closed",
                                                children: "Post a Comment"
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        })
    });
}

;// CONCATENATED MODULE: ./components/blog/BlogCard2.js


function BlogCard2({ item  }) {
    return /*#__PURE__*/ jsx_runtime.jsx(jsx_runtime.Fragment, {
        children: /*#__PURE__*/ jsx_runtime.jsx("div", {
            className: "col-xl-6 col-lg-6 col-md-6 col-sm-6 ",
            children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: "blog_box type_one trans hover_1_get borenable",
                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "blog_inner trans",
                    children: [
                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                            className: "vertical_text_1",
                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("span", {
                                className: "date_tm",
                                children: [
                                    /*#__PURE__*/ jsx_runtime.jsx("i", {
                                        className: "fi-rr-calendar"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("time", {
                                        className: "date published",
                                        children: [
                                            "Jan 3, ",
                                            new Date().getFullYear()
                                        ]
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "image_box trans hover_1",
                            children: [
                                /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                    href: `/blog/${item.id}`,
                                    children: /*#__PURE__*/ jsx_runtime.jsx("img", {
                                        src: `/assets/images/blog/${item.img}`,
                                        className: "img-fluid",
                                        alt: "img"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    className: "oh ho_1"
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    className: "oh ho_2"
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    className: "oh ho_3"
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    className: "oh ho_4"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "content",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "d-flex authour align-items-center",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime.jsx("img", {
                                            src: "/assets/images/gavatar.png",
                                            alt: "gavatar",
                                            className: "img-fluid"
                                        }),
                                        " Jason P Laforce"
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("h4", {
                                    className: "title_22",
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)((link_default()), {
                                        href: `/blog/${item.id}`,
                                        children: [
                                            " ",
                                            item.title
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("p", {
                                    className: "descs",
                                    children: " Sed ut perspiciatis unde omnis iste natus error sit voluptatem…"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)((link_default()), {
                                    href: "/blog-details",
                                    className: "rd_more",
                                    children: [
                                        "Read More ",
                                        /*#__PURE__*/ jsx_runtime.jsx("i", {
                                            className: "fi-rr-arrow-small-right"
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            })
        })
    });
}

;// CONCATENATED MODULE: ./components/blog/BlogCard3.js


function BlogCard3({ item  }) {
    return /*#__PURE__*/ jsx_runtime.jsx(jsx_runtime.Fragment, {
        children: /*#__PURE__*/ jsx_runtime.jsx("div", {
            className: "col-xl-4 col-lg-4 col-md-6 col-sm-6",
            children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: "blog_box type_two trans hover_1_get",
                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "blog_inner trans",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "image_box trans hover_1",
                            children: [
                                /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                    href: `/blog/${item.id}`,
                                    children: /*#__PURE__*/ jsx_runtime.jsx("img", {
                                        src: `/assets/images/blog/${item.img}`,
                                        className: "img-fluid",
                                        alt: "img"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    className: "oh ho_1"
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    className: "oh ho_2"
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    className: "oh ho_3"
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    className: "oh ho_4"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("span", {
                                    className: "date_tm",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime.jsx("i", {
                                            className: "fi-rr-calendar"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("time", {
                                            className: "date published",
                                            children: [
                                                "Jan 3, ",
                                                new Date().getFullYear()
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "content",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "d-flex authour align-items-center",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime.jsx("img", {
                                            src: "/assets/images/gavatar.png",
                                            alt: "gavatar",
                                            className: "img-fluid"
                                        }),
                                        " Bradley R Grady"
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("h4", {
                                    className: "title_22",
                                    children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                        href: `/blog/${item.id}`,
                                        children: "Former insures only the marine perils"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("p", {
                                    className: "descs",
                                    children: " Sed ut perspiciatis unde omnis iste natus error sit voluptatem…"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "bottn_flex",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)((link_default()), {
                                            href: "/blog-details",
                                            className: "rd_more",
                                            children: [
                                                "Read More ",
                                                /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                    className: "fi-rr-arrow-small-right"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("small", {
                                            className: "comments",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                    className: "far fa-comment-dots"
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                    href: `/blog/${item.id}`,
                                                    className: "Comments are Closed",
                                                    children: "Post a Comment"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            })
        })
    });
}

;// CONCATENATED MODULE: ./components/blog/Pagination.js

function Pagination({ prev , currentPage , getPaginationGroup , next , pages , handleActive  }) {
    return /*#__PURE__*/ jsx_runtime.jsx(jsx_runtime.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
            className: "pagination justify-content-center",
            children: [
                getPaginationGroup.length <= 0 ? null : /*#__PURE__*/ jsx_runtime.jsx("li", {
                    onClick: prev,
                    className: "next_link page-item",
                    children: currentPage === 1 ? null : /*#__PURE__*/ jsx_runtime.jsx("a", {
                        children: /*#__PURE__*/ jsx_runtime.jsx("i", {
                            className: "fa fa-arrow-left"
                        })
                    })
                }),
                getPaginationGroup.map((item, index)=>{
                    return /*#__PURE__*/ jsx_runtime.jsx("li", {
                        onClick: ()=>handleActive(item),
                        className: currentPage === item ? "page-item active" : "page-item",
                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                            className: "page-link",
                            children: item
                        })
                    }, index);
                }),
                getPaginationGroup.length <= 0 ? null : /*#__PURE__*/ jsx_runtime.jsx("li", {
                    onClick: next,
                    className: "next_link page-item",
                    children: currentPage >= pages ? null : /*#__PURE__*/ jsx_runtime.jsx("a", {
                        children: /*#__PURE__*/ jsx_runtime.jsx("i", {
                            className: "fa fa-arrow-right"
                        })
                    })
                })
            ]
        })
    });
}

;// CONCATENATED MODULE: ./components/blog/BlogPost.js







function BlogPost({ style , showItem , showPagination  }) {
    // console.log(products);
    let [currentPage, setCurrentPage] = (0,external_react_.useState)(1);
    let showLimit = showItem, paginationItem = 4;
    let [pagination, setPagination] = (0,external_react_.useState)([]);
    let [limit, setLimit] = (0,external_react_.useState)(showLimit);
    let [pages, setPages] = (0,external_react_.useState)(Math.ceil(blog.length / limit));
    (0,external_react_.useEffect)(()=>{
        cratePagination();
    }, [
        limit,
        pages,
        blog.length
    ]);
    const cratePagination = ()=>{
        // set pagination
        let arr = new Array(Math.ceil(blog.length / limit)).fill().map((_, idx)=>idx + 1);
        setPagination(arr);
        setPages(Math.ceil(blog.length / limit));
    };
    const startIndex = currentPage * limit - limit;
    const endIndex = startIndex + limit;
    const getPaginatedProducts = blog.slice(startIndex, endIndex);
    let start = Math.floor((currentPage - 1) / paginationItem) * paginationItem;
    let end = start + paginationItem;
    const getPaginationGroup = pagination.slice(start, end);
    const next = ()=>{
        setCurrentPage((page)=>page + 1);
    };
    const prev = ()=>{
        setCurrentPage((page)=>page - 1);
    };
    const handleActive = (item)=>{
        setCurrentPage(item);
    };
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            getPaginatedProducts.length === 0 && /*#__PURE__*/ jsx_runtime.jsx("h3", {
                children: "No Products Found "
            }),
            getPaginatedProducts.map((item)=>/*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                    children: [
                        !style && /*#__PURE__*/ jsx_runtime.jsx(BlogCard1, {
                            item: item
                        }, item.id),
                        style === 1 && /*#__PURE__*/ jsx_runtime.jsx(BlogCard1, {
                            item: item
                        }, item.id),
                        style === 2 && /*#__PURE__*/ jsx_runtime.jsx(BlogCard2, {
                            item: item
                        }, item.id),
                        style === 3 && /*#__PURE__*/ jsx_runtime.jsx(BlogCard3, {
                            item: item
                        }, item.id)
                    ]
                })),
            showPagination && /*#__PURE__*/ jsx_runtime.jsx(Pagination, {
                getPaginationGroup: getPaginationGroup,
                currentPage: currentPage,
                pages: pages,
                next: next,
                prev: prev,
                handleActive: handleActive
            })
        ]
    });
}


/***/ })

};
;