(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 1593:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
;// CONCATENATED MODULE: ./components/elements/Preloader.js

function Preloader() {
    return /*#__PURE__*/ jsx_runtime.jsx(jsx_runtime.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "loader-wrap",
            children: [
                /*#__PURE__*/ jsx_runtime.jsx("div", {
                    className: "preloader",
                    children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                        className: "preloader-close",
                        children: /*#__PURE__*/ jsx_runtime.jsx("i", {
                            className: "fi-rr-cross"
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime.jsx("div", {
                    className: "layer",
                    children: " "
                }),
                /*#__PURE__*/ jsx_runtime.jsx("div", {
                    className: "animation-preloader",
                    children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                        className: "spinner"
                    })
                })
            ]
        })
    });
}

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/swiper/swiper.min.css
var swiper_min = __webpack_require__(8722);
// EXTERNAL MODULE: ./node_modules/swiper/modules/navigation/navigation.min.css
var navigation_min = __webpack_require__(9176);
// EXTERNAL MODULE: ./node_modules/swiper/modules/pagination/pagination.min.css
var pagination_min = __webpack_require__(2996);
// EXTERNAL MODULE: ./public/assets/css/plugins/animate.min.css
var animate_min = __webpack_require__(1931);
// EXTERNAL MODULE: ./public/assets/css/plugins/bootstrap.min.css
var bootstrap_min = __webpack_require__(3918);
// EXTERNAL MODULE: ./public/assets/css/plugins/jquery.fancybox.min.css
var jquery_fancybox_min = __webpack_require__(7909);
// EXTERNAL MODULE: ./public/assets/css/plugins/owl.css
var owl = __webpack_require__(4907);
// EXTERNAL MODULE: ./public/assets/css/plugins/rangeslider.css
var rangeslider = __webpack_require__(7466);
// EXTERNAL MODULE: ./public/assets/css/plugins/select.min.css
var select_min = __webpack_require__(9473);
// EXTERNAL MODULE: ./public/assets/css/plugins/slick.css
var slick = __webpack_require__(6004);
// EXTERNAL MODULE: ./public/assets/css/global-settings.css
var global_settings = __webpack_require__(1684);
// EXTERNAL MODULE: ./public/assets/css/theme.css
var theme = __webpack_require__(1967);
// EXTERNAL MODULE: ./public/assets/css/plugins/flaticon_vankine.css
var flaticon_vankine = __webpack_require__(3843);
// EXTERNAL MODULE: ./public/assets/css/plugins/font-awesome.min.css
var font_awesome_min = __webpack_require__(1529);
// EXTERNAL MODULE: ./public/assets/css/plugins/uicons-regular-rounded.css
var uicons_regular_rounded = __webpack_require__(2027);
// EXTERNAL MODULE: ./public/assets/css/plugins/uicons-regular-straight.css
var uicons_regular_straight = __webpack_require__(8679);
;// CONCATENATED MODULE: ./pages/_app.js



















function MyApp({ Component , pageProps  }) {
    const [loading, setLoading] = (0,external_react_.useState)(true);
    (0,external_react_.useEffect)(()=>{
        setTimeout(()=>{
            setLoading(false);
        }, 1000);
    }, []);
    return /*#__PURE__*/ jsx_runtime.jsx(jsx_runtime.Fragment, {
        children: !loading ? /*#__PURE__*/ jsx_runtime.jsx(Component, {
            ...pageProps
        }) : /*#__PURE__*/ jsx_runtime.jsx(Preloader, {})
    });
}
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 9176:
/***/ (() => {



/***/ }),

/***/ 2996:
/***/ (() => {



/***/ }),

/***/ 8722:
/***/ (() => {



/***/ }),

/***/ 1684:
/***/ (() => {



/***/ }),

/***/ 1931:
/***/ (() => {



/***/ }),

/***/ 3918:
/***/ (() => {



/***/ }),

/***/ 3843:
/***/ (() => {



/***/ }),

/***/ 1529:
/***/ (() => {



/***/ }),

/***/ 7909:
/***/ (() => {



/***/ }),

/***/ 4907:
/***/ (() => {



/***/ }),

/***/ 7466:
/***/ (() => {



/***/ }),

/***/ 9473:
/***/ (() => {



/***/ }),

/***/ 6004:
/***/ (() => {



/***/ }),

/***/ 2027:
/***/ (() => {



/***/ }),

/***/ 8679:
/***/ (() => {



/***/ }),

/***/ 1967:
/***/ (() => {



/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [893], () => (__webpack_exec__(1593)));
module.exports = __webpack_exports__;

})();